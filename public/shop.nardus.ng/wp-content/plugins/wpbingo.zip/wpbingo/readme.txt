=== Wpbingo Woocommerce ===

Register shortcodes for wpbingo ecommerce theme.

version: 1.0.0